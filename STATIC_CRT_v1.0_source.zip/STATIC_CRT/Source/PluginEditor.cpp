#include "PluginEditor.h"

namespace
{
    const juce::Colour bg (0xff090b10), panel (0xff111722), mint (0xff78f0c0), cyan (0xff5bd7e8), muted (0xff82909e);
}

StaticCrtAudioProcessorEditor::StaticCrtAudioProcessorEditor (StaticCrtAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), xyPad (p)
{
    setSize (900, 600);
    title.setText ("STATIC CRT", juce::dontSendNotification);
    title.setFont (juce::Font (juce::FontOptions (31.0f, juce::Font::bold)));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);
    subtitle.setText ("ANALOG MOTION  /  DIGITAL DECAY", juce::dontSendNotification);
    subtitle.setFont (juce::Font (juce::FontOptions (10.0f, juce::Font::bold)));
    subtitle.setColour (juce::Label::textColourId, muted);
    addAndMakeVisible (subtitle);
    addAndMakeVisible (xyPad);

    addKnob ("MIX", "mix", 0, 1);
    addKnob ("AMOUNT", "amount", 0, 1);
    addKnob ("RATE", "rate", 0.03f, 8);
    addKnob ("CRUSH", "crush", 0, 1);
    addKnob ("FILTER", "filter", 0, 1);
    addKnob ("NOISE", "noise", 0, 1);
    addKnob ("DRIVE", "drive", 0, 1);
    addKnob ("WIDTH", "width", 0, 2);
    addKnob ("WOW", "wow", 0, 1);
    addKnob ("FLUTTER", "flutter", 0, 1);

    presets.addItem ("01  /  CRT DEFAULT", 1);
    presets.addItem ("02  /  WORN TAPE", 2);
    presets.addItem ("03  /  WARPED SIGNAL", 3);
    presets.addItem ("04  /  BIT ROT", 4);
    presets.addItem ("05  /  GHOST CHANNEL", 5);
    presets.setSelectedId (1, juce::dontSendNotification);
    presets.setColour (juce::ComboBox::backgroundColourId, panel);
    presets.setColour (juce::ComboBox::textColourId, juce::Colours::white);
    presets.setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff293644));
    presets.onChange = [this] { audioProcessor.loadPreset (presets.getSelectedId() - 1); };
    addAndMakeVisible (presets);

    bypassButton.setClickingTogglesState (true);
    bypassButton.setColour (juce::TextButton::buttonColourId, panel);
    bypassButton.setColour (juce::TextButton::textColourOffId, muted);
    bypassButton.onClick = [this] {
        bypassed = bypassButton.getToggleState();
        if (auto* b = audioProcessor.parameters.getParameter ("bypass"))
            b->setValueNotifyingHost (bypassed ? 1.0f : 0.0f);
    };
    addAndMakeVisible (bypassButton);
    startTimerHz (24);
}

void StaticCrtAudioProcessorEditor::addKnob (const juce::String& name, const juce::String& id, float min, float max)
{
    auto k = std::make_unique<Knob>();
    k->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 68, 18);
    k->slider.setRange (min, max, 0.001);
    k->slider.setColour (juce::Slider::rotarySliderFillColourId, mint);
    k->slider.setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff293644));
    k->slider.setColour (juce::Slider::thumbColourId, juce::Colours::white);
    k->slider.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    k->slider.setColour (juce::Slider::textBoxBackgroundColourId, panel);
    k->label.setText (name, juce::dontSendNotification);
    k->label.setJustificationType (juce::Justification::centred);
    k->label.setFont (juce::Font (juce::FontOptions (10.0f, juce::Font::bold)));
    k->label.setColour (juce::Label::textColourId, muted);
    k->attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (audioProcessor.parameters, id, k->slider);
    addAndMakeVisible (k->slider); addAndMakeVisible (k->label);
    knobs.push_back (std::move (k));
}

void StaticCrtAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (bg);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff141e2a), 0, 0, bg, 900, 600, false));
    g.fillRoundedRectangle (18, 94, 864, 460, 18);
    g.setColour (juce::Colour (0xff263342)); g.drawRoundedRectangle (18, 94, 864, 460, 18, 1.0f);
    g.setColour (mint.withAlpha (0.75f)); g.fillRoundedRectangle (18, 94, 4, 460, 2);
    g.setColour (muted.withAlpha (0.35f));
    for (int y = 110; y < 545; y += 5) g.drawHorizontalLine (y, 28, 872);
    g.setColour (juce::Colour (0xff1c2935)); g.drawLine (36, 160, 864, 160, 1.0f);
    g.setColour (muted); g.setFont (juce::Font (juce::FontOptions (9.0f, juce::Font::bold)));
    g.drawText ("MOTION MATRIX", 48, 174, 220, 16, juce::Justification::left);
    g.drawText ("TONE  /  TEXTURE", 48, 374, 220, 16, juce::Justification::left);
    g.setColour (mint.withAlpha (0.75f)); g.drawText ("V1.0.0  •  STEREO FX", 690, 44, 190, 18, juce::Justification::right);
}

void StaticCrtAudioProcessorEditor::resized()
{
    title.setBounds (28, 18, 300, 42); subtitle.setBounds (31, 59, 300, 18);
    presets.setBounds (600, 30, 220, 30); bypassButton.setBounds (830, 30, 62, 30);
    xyPad.setBounds (48, 198, 330, 155);
    const int startX = 405, startY = 183, w = 88, h = 164, gap = 8;
    for (size_t i = 0; i < knobs.size(); ++i)
    {
        const int row = (int) i / 5, col = (int) i % 5;
        const int x = startX + col * (w + gap), y = startY + row * h;
        knobs[i]->label.setBounds (x, y, w, 18);
        knobs[i]->slider.setBounds (x + 4, y + 20, w - 8, 112);
    }
}

void StaticCrtAudioProcessorEditor::timerCallback() { xyPad.repaint(); }

void StaticCrtAudioProcessorEditor::XYPad::update (juce::Point<float> p)
{
    const float x = juce::jlimit (0.0f, 1.0f, p.x / (float) getWidth());
    const float y = juce::jlimit (0.0f, 1.0f, p.y / (float) getHeight());
    if (auto* a = processor.parameters.getParameter ("amount")) a->setValueNotifyingHost (x);
    if (auto* r = processor.parameters.getParameter ("rate")) r->setValueNotifyingHost (1.0f - y);
}
void StaticCrtAudioProcessorEditor::XYPad::mouseDown (const juce::MouseEvent& e) { update (e.position); }
void StaticCrtAudioProcessorEditor::XYPad::mouseDrag (const juce::MouseEvent& e) { update (e.position); }
void StaticCrtAudioProcessorEditor::XYPad::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (juce::Colour (0xff070b10)); g.fillRoundedRectangle (r, 10);
    g.setColour (juce::Colour (0xff263846)); g.drawRoundedRectangle (r, 10, 1.0f);
    g.saveState(); g.reduceClipRegion (getLocalBounds());
    g.setColour (cyan.withAlpha (0.12f));
    for (int x = 16; x < getWidth(); x += 24) g.drawVerticalLine (x, 0, (float) getHeight());
    for (int y = 16; y < getHeight(); y += 24) g.drawHorizontalLine (y, 0, (float) getWidth());
    const float amount = processor.parameters.getRawParameterValue ("amount")->load();
    const float rate = processor.parameters.getRawParameterValue ("rate")->load();
    const float nx = amount * (float) getWidth();
    const float ny = (1.0f - (rate - 0.03f) / 7.97f) * (float) getHeight();
    g.setColour (mint.withAlpha (0.7f));
    juce::Path wave; wave.startNewSubPath (0, getHeight() * 0.52f);
    for (int x = 0; x < getWidth(); ++x)
    {
        const float t = (float) x / (float) getWidth();
        const float yy = getHeight() * 0.52f + std::sin (t * juce::MathConstants<float>::twoPi * 2.2f) * (8.0f + amount * 30.0f)
                       + std::sin (t * 51.0f + (float) juce::Time::getMillisecondCounter() * 0.002f) * 2.0f;
        wave.lineTo ((float) x, yy);
    }
    g.strokePath (wave, juce::PathStrokeType (1.6f));
    g.setColour (mint.withAlpha (0.16f)); g.fillEllipse (nx - 15, ny - 15, 30, 30);
    g.setColour (mint); g.fillEllipse (nx - 5, ny - 5, 10, 10);
    g.restoreState();
    g.setColour (muted); g.setFont (juce::Font (juce::FontOptions (9.0f, juce::Font::bold)));
    g.drawText ("AMOUNT  →", 10, 6, 90, 14, juce::Justification::left);
    g.drawText ("RATE  ↑", getWidth() - 65, 6, 55, 14, juce::Justification::right);
}
