#pragma once
#include <JuceHeader.h>

class StaticCrtAudioProcessor final : public juce::AudioProcessor
{
public:
    StaticCrtAudioProcessor();
    ~StaticCrtAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.15; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    using APVTS = juce::AudioProcessorValueTreeState;
    APVTS parameters;
    static APVTS::ParameterLayout createParameterLayout();
    void loadPreset (int presetIndex);

private:
    float readDelay (int channel, float delaySamples) const noexcept;
    float processSample (float input, int channel) noexcept;

    double currentSampleRate = 44100.0;
    juce::AudioBuffer<float> delayBuffer;
    int delayWritePosition = 0;
    float lfoPhase = 0.0f;
    float crushPhase = 0.0f;
    float heldSample[2] { 0.0f, 0.0f };
    float filterState[2] { 0.0f, 0.0f };
    juce::uint32 noiseState = 0x1234567u;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (StaticCrtAudioProcessor)
};
