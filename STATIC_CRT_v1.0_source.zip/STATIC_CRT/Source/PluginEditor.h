#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class StaticCrtAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                           private juce::Timer
{
public:
    explicit StaticCrtAudioProcessorEditor (StaticCrtAudioProcessor&);
    ~StaticCrtAudioProcessorEditor() override = default;
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    class XYPad final : public juce::Component
    {
    public:
        explicit XYPad (StaticCrtAudioProcessor& p) : processor (p) {}
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
    private:
        void update (juce::Point<float>);
        StaticCrtAudioProcessor& processor;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (XYPad)
    };
    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    };
    void addKnob (const juce::String&, const juce::String&, float, float);
    void timerCallback() override;

    StaticCrtAudioProcessor& audioProcessor;
    XYPad xyPad;
    std::vector<std::unique_ptr<Knob>> knobs;
    juce::ComboBox presets;
    juce::Label title, subtitle, presetLabel;
    juce::TextButton bypassButton { "BYPASS" };
    bool bypassed = false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (StaticCrtAudioProcessorEditor)
};
