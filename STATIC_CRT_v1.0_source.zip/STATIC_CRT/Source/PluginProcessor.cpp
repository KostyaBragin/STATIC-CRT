#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    juce::AudioParameterFloat* floatParam (const juce::String& id, const juce::String& name,
                                           float min, float max, float def,
                                           juce::String suffix = {})
    {
        return new juce::AudioParameterFloat ({ id, 1 }, name,
            juce::NormalisableRange<float> (min, max), def, suffix);
    }
}

StaticCrtAudioProcessor::StaticCrtAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                       .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMETERS", createParameterLayout())
{}

StaticCrtAudioProcessor::APVTS::ParameterLayout StaticCrtAudioProcessor::createParameterLayout()
{
    APVTS::ParameterLayout p;
    p.add (floatParam ("mix", "Mix", 0.0f, 1.0f, 0.72f));
    p.add (floatParam ("amount", "Amount", 0.0f, 1.0f, 0.48f));
    p.add (floatParam ("rate", "Rate", 0.03f, 8.0f, 0.65f, " Hz"));
    p.add (floatParam ("crush", "Crush", 0.0f, 1.0f, 0.18f));
    p.add (floatParam ("filter", "Filter", 0.0f, 1.0f, 0.22f));
    p.add (floatParam ("noise", "Noise", 0.0f, 1.0f, 0.08f));
    p.add (floatParam ("drive", "Drive", 0.0f, 1.0f, 0.24f));
    p.add (floatParam ("width", "Width", 0.0f, 2.0f, 1.0f));
    p.add (floatParam ("wow", "Wow", 0.0f, 1.0f, 0.52f));
    p.add (floatParam ("flutter", "Flutter", 0.0f, 1.0f, 0.28f));
    p.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "bypass", 1 }, "Bypass", false));
    return p;
}

void StaticCrtAudioProcessor::prepareToPlay (double sr, int samplesPerBlock)
{
    juce::ignoreUnused (samplesPerBlock);
    currentSampleRate = sr;
    delayBuffer.setSize (2, juce::jmax (8, (int) std::ceil (sr * 0.06)), false, true, true);
    delayBuffer.clear();
    delayWritePosition = 0;
    lfoPhase = crushPhase = 0.0f;
    filterState[0] = filterState[1] = 0.0f;
}

void StaticCrtAudioProcessor::releaseResources() {}

bool StaticCrtAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return in == out && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

float StaticCrtAudioProcessor::readDelay (int ch, float delaySamples) const noexcept
{
    const int size = delayBuffer.getNumSamples();
    float pos = (float) delayWritePosition - delaySamples;
    while (pos < 0.0f) pos += (float) size;
    while (pos >= (float) size) pos -= (float) size;
    const int i0 = (int) pos;
    const int i1 = (i0 + 1) % size;
    const float frac = pos - (float) i0;
    return delayBuffer.getSample (juce::jmin (ch, delayBuffer.getNumChannels() - 1), i0) * (1.0f - frac)
         + delayBuffer.getSample (juce::jmin (ch, delayBuffer.getNumChannels() - 1), i1) * frac;
}

float StaticCrtAudioProcessor::processSample (float x, int ch) noexcept
{
    const float amount = parameters.getRawParameterValue ("amount")->load();
    const float rate = parameters.getRawParameterValue ("rate")->load();
    const float crush = parameters.getRawParameterValue ("crush")->load();
    const float cutoff = 20000.0f * std::pow (0.025f, parameters.getRawParameterValue ("filter")->load());
    const float noise = parameters.getRawParameterValue ("noise")->load();
    const float drive = parameters.getRawParameterValue ("drive")->load();
    const float wow = parameters.getRawParameterValue ("wow")->load();
    const float flutter = parameters.getRawParameterValue ("flutter")->load();

    const float slow = std::sin (lfoPhase) * wow;
    const float fast = std::sin (lfoPhase * 7.31f + 0.8f) * flutter;
    const float delayMs = 2.0f + (slow * 2.4f + fast * 0.55f) * amount;
    const float delayed = readDelay (ch, juce::jlimit (1.0f, (float) delayBuffer.getNumSamples() - 2.0f,
                                      delayMs * 0.001f * (float) currentSampleRate));
    delayBuffer.setSample (ch, delayWritePosition, x);

    const float blend = amount * 0.82f;
    float y = x * (1.0f - blend) + delayed * blend;

    const float crushed = heldSample[juce::jmin (ch, 1)];
    y = y * (1.0f - crush * 0.82f) + crushed * (crush * 0.82f);

    const float alpha = 1.0f - std::exp (-2.0f * juce::MathConstants<float>::pi * cutoff / (float) currentSampleRate);
    filterState[ch] += alpha * (y - filterState[ch]);
    y = y * (1.0f - parameters.getRawParameterValue ("filter")->load() * 0.75f)
      + filterState[ch] * parameters.getRawParameterValue ("filter")->load() * 0.75f;

    const float gain = 1.0f + drive * 14.0f;
    const float saturated = std::tanh (y * gain) / std::tanh (gain);
    y = y * (1.0f - drive * 0.8f) + saturated * (drive * 0.8f);

    noiseState ^= noiseState << 13; noiseState ^= noiseState >> 17; noiseState ^= noiseState << 5;
    const float n = ((float) (noiseState & 0xffffu) / 32767.5f - 1.0f) * noise * 0.035f;
    return y + n;
}

void StaticCrtAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused (midi);
    juce::ScopedNoDenormals noDenormals;
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (parameters.getRawParameterValue ("bypass")->load() > 0.5f) return;
    const float mix = parameters.getRawParameterValue ("mix")->load();
    const float rate = parameters.getRawParameterValue ("rate")->load();
    const float width = parameters.getRawParameterValue ("width")->load();
    const float phaseInc = juce::MathConstants<float>::twoPi * rate / (float) currentSampleRate;

    for (int i = 0; i < samples; ++i)
    {
        const float dryL = buffer.getSample (0, i);
        const float dryR = channels > 1 ? buffer.getSample (1, i) : dryL;
        if (crushPhase <= 0.0f)
        {
            const float crush = parameters.getRawParameterValue ("crush")->load();
            const float levels = 256.0f * std::pow (1.0f / 256.0f, crush);
            heldSample[0] = std::round (dryL * levels) / levels;
            heldSample[1] = std::round (dryR * levels) / levels;
            crushPhase = 1.0f + crush * 95.0f;
        }
        float wetL = processSample (dryL, 0);
        float wetR = channels > 1 ? processSample (dryR, 1) : wetL;
        const float mid = (wetL + wetR) * 0.5f;
        const float side = (wetL - wetR) * 0.5f * width;
        wetL = mid + side; wetR = mid - side;
        buffer.setSample (0, i, dryL * (1.0f - mix) + wetL * mix);
        if (channels > 1) buffer.setSample (1, i, dryR * (1.0f - mix) + wetR * mix);
        lfoPhase += phaseInc;
        if (lfoPhase >= juce::MathConstants<float>::twoPi) lfoPhase -= juce::MathConstants<float>::twoPi;
        crushPhase -= 1.0f;
        delayWritePosition = (delayWritePosition + 1) % juce::jmax (1, delayBuffer.getNumSamples());
    }
}

void StaticCrtAudioProcessor::loadPreset (int index)
{
    struct P { float amount, rate, crush, filter, noise, drive, mix, wow, flutter; };
    static constexpr P presets[] = {
        { .48f, .65f, .18f, .22f, .08f, .24f, .72f, .52f, .28f },
        { .82f, .22f, .08f, .38f, .16f, .12f, .80f, .92f, .12f },
        { .62f, 4.2f, .55f, .12f, .04f, .35f, .68f, .18f, .88f },
        { .35f, .48f, .82f, .55f, .28f, .48f, .76f, .35f, .22f },
        { .90f, 1.1f, .30f, .68f, .62f, .18f, .90f, .75f, .44f }
    };
    const auto v = presets[juce::jlimit (0, 4, index)];
    const std::pair<const char*, float> values[] = {
        {"amount",v.amount},{"rate",v.rate},{"crush",v.crush},{"filter",v.filter},
        {"noise",v.noise},{"drive",v.drive},{"mix",v.mix},{"wow",v.wow},{"flutter",v.flutter}
    };
    for (auto [id, value] : values)
        if (auto* param = parameters.getParameter (id)) param->setValueNotifyingHost (param->convertTo0to1 (value));
}

juce::AudioProcessorEditor* StaticCrtAudioProcessor::createEditor() { return new StaticCrtAudioProcessorEditor (*this); }
void StaticCrtAudioProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, dest);
}
void StaticCrtAudioProcessor::setStateInformation (const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, size));
    if (xml != nullptr && xml->hasTagName (parameters.state.getType())) parameters.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new StaticCrtAudioProcessor(); }
