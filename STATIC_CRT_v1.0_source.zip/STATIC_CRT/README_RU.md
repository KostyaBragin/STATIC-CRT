# STATIC CRT — VST3 effect (Windows 10/11 x64)

Самостоятельный lo-fi / tape-motion / digital-degradation эффект. Это оригинальная реализация с собственным DSP и интерфейсом, а не копия исходного кода или графики Cymatics.

## Что входит
- VST3 stereo effect, JUCE 8, C++17
- Mix, Amount, Rate, Crush, Filter, Noise, Drive, Width, Wow, Flutter
- XY-панель: X управляет Amount, Y управляет Rate
- 5 заводских стартовых пресетов
- Состояние параметров сохраняется в проекте DAW; параметры доступны для host automation
- Авторский тёмный интерфейс с CRT-сеткой и движущейся осциллограммой

## Сборка под Windows

Требуется:
1. Windows 10/11 x64
2. Visual Studio 2022 с workload **Desktop development with C++**
3. CMake 3.22 или новее
4. Git и доступ к GitHub при первой сборке (JUCE 8.0.10 скачивается через CMake FetchContent)

Шаги:
1. Распакуйте папку проекта.
2. Откройте `x64 Native Tools Command Prompt for VS 2022` либо обычный терминал, где доступны CMake и MSVC.
3. Перейдите в папку `STATIC_CRT`.
4. Запустите `build_windows.bat`.
5. После успешной сборки папка плагина будет в `build\STATICCRT_artefacts\Release\VST3\STATIC CRT.vst3`.
6. Скопируйте всю папку `.vst3` в `C:\Program Files\Common Files\VST3`, затем обновите список плагинов в DAW.

## Примечания
- При первой конфигурации CMake скачивает JUCE. Поэтому нужен интернет.
- Проект создаёт VST3, не standalone-приложение.
- В текущей версии XY-панель управляет Amount и Rate; ручки Wow и Flutter задают глубину соответствующих видов нестабильности.
- Это v1.0 starter build: перед коммерческим релизом необходимы тесты в целевых DAW, проверка параметров/пресетов и DSP QA.
