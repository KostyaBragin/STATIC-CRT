@echo off
setlocal
where cmake >nul 2>nul || (echo CMake is not installed. Install CMake 3.22+ and Visual Studio 2022. & exit /b 1)
cmake -S . -B build -A x64 -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b %errorlevel%
cmake --build build --config Release --target STATICCRT_VST3
if errorlevel 1 exit /b %errorlevel%
echo.
echo Build complete. Look in build\STATICCRT_artefacts\Release\VST3\STATIC CRT.vst3
echo Copy the entire .vst3 folder to %%COMMONPROGRAMFILES%%\VST3
endlocal
